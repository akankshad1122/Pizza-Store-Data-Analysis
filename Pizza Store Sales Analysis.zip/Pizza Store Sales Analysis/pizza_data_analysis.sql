--KPIs

--Total Revenue
select sum(total_price) as total_revenue from pizza_sales;

--Average Order Value
select sum(total_price)/count(distinct order_id) as avg_order_value from pizza_sales;

--Total Pizzas Sold
select sum(quantity) as tot_pizzas_sold from pizza_sales;

--Total Orders
select count(distinct order_id) as tot_orders from pizza_sales;

--Avg Pizzas Per Order
select cast(cast(sum(quantity) as decimal(10,2))/cast(count(distinct order_id) as decimal(10,2))as decimal(10,2)) as avg_pizzas_per_order from pizza_sales;

--Requirements

--Hourly Trend of Pizzas Sold
select DATE_PART('hour', order_time) as ord_hr, sum(quantity) as tot_pizzas
from pizza_sales
group by ord_hr
order by ord_hr;

--Weekly Trend of Total Orders
select extract('week' from order_date) as week_no, date_part('year', order_date) as yr, count(distinct order_id) as tot_ords
from pizza_sales
group by week_no, yr
order by week_no, yr;

--% of sales by pizza category
select pizza_category, sum(total_price)*100/(select sum(total_price) from pizza_sales) as percentage_sales
from pizza_sales
group by pizza_category;

--% of sale by pizza size
select pizza_size, sum(total_price)*100/(select sum(total_price) from pizza_sales) as percentage_sales
from pizza_sales
group by pizza_size;

--top 5 pizzas by revenue
select pizza_name, sum(total_price) as total_revenue
from pizza_sales
group by pizza_name
order by total_revenue desc
fetch first 5 rows only;

--bottom 5 pizzas by revenue
select pizza_name, sum(total_price) as total_revenue
from pizza_sales
group by pizza_name
order by total_revenue
limit 5;